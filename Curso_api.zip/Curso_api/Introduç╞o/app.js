var http = require("http");


console.log("servidor rodando na porta 8181")
http.createServer(function(resquisicao,resposta){
    resposta.end("<h1>bem vindo malandro</h1><h4>kkkk ala o corno</h4>")
}).listen(3000)