Este é um projeto desenvolvido na equipe da Autoplay.
Possui como objetivo realizar agendamentos de salas disponíveis de acordo com as datas do calendário presente no site.